# !/usr/bin/env python3
"""
工具类。
"""


import json
import traceback

import numpy as np


def convert_example(examples: dict, tokenizer, max_source_seq_len: int, max_target_seq_len: int):
    """
    将样本数据转换为模型接收的输入数据。

    Args:
        examples (dict): 训练数据样本, e.g. -> {
                                                "text": [
                                                            '{"context": "年基准利率4.35%。从实际看...", "answer": "年基准利率4.35%", "question": "2017年银行贷款基准利率", "id": 0}',
                                                            ...
                                                ]
                                            }
        max_source_seq_len (int): encoder 最大输入长度
        max_target_seq_len (int): decoder 最大输入长度

    Returns:
        dict (str: np.array) -> tokenized_output = {
                            'input_ids': [[1525, 10, ...], [758, 2345, ...]], 
                            'attention_mask': [[1, 1, ...], [1, 1, ...]],
                            'labels': [[822, 10, ...], [125, 58...]]
                        }
    """
    tokenized_output = {
            'input_ids': [],                                # encoder 输入
            'attention_mask': [],                           # encoder attention mask
            'labels': []                                    # decoder 标签
        }

    for example in examples['text']:
        try:
            example = json.loads(example)
            document = example["document"]
            summary = example["summary"]

            input_seq = f'summarize：{document}'

            inputs = tokenizer(                                                         # 处理 encoder 输入
                text=input_seq,
                truncation=True,
                max_length=max_source_seq_len,
            )

            # Setup the tokenizer for targets
            with tokenizer.as_target_tokenizer():
                labels = tokenizer(examples["summary"], max_length=max_target_seq_len, truncation=True)

        except:
            print(f'"{example}" -> {traceback.format_exc()}')
            continue

        tokenized_output['input_ids'].append(inputs["input_ids"])
        tokenized_output['attention_mask'].append(inputs["attention_mask"])
        tokenized_output['labels'].append(labels)

    for k, v in tokenized_output.items():
        tokenized_output[k] = np.array(v)

    return tokenized_output


if __name__ == '__main__':
    from rich import print
    from transformers import BertTokenizer

    tokenizer = BertTokenizer.from_pretrained("uer/t5-small")

    res = convert_example({
                "text": [
                    "{\"document\": \"Media playback is unsupported on your device\n18 December 2014 Last updated at 10:28 GMT\nMalaysia has successfully tackled poverty over the last four decades by drawing on its rich natural resources.\nAccording to the World Bank, some 49% of Malaysians in 1970 were extremely poor, and that figure has been reduced to 1% today. However, the government's next challenge is to help the lower income group to move up to the middle class, the bank says.\nUlrich Zahau, the World Bank's Southeast Asia director, spoke to the BBC's Jennifer Pak.	\", \"summary\": \"In Malaysia the 'aspirational' low-income part of the population is helping to drive economic growth through consumption, according to the World Bank.\"}"
                ]
            },
            tokenizer=tokenizer,
            max_source_seq_len=1024,
            max_target_seq_len=128
    )
    print(res)
    print('input_ids: ', tokenizer.convert_ids_to_tokens(res['input_ids'][0]))
    print('labels: ', tokenizer.convert_ids_to_tokens(res['labels'][0]))
